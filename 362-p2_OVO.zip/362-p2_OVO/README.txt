CPSC362--02
PROJECT 2 VCSPROJCET----Check In& Check Out& Label

Team Name: OVO

Team Member: 
Xinyu Wen,  XINYUWEN@CSU.FULLERTON.EDU
Xianghui Huang,  JERRYHUANG6666@GMAIL.COM 
Yintao Wang,  WYT@CSU.FULLERTON.EDU

Intro:
In this project we split the project into 3 parts.
Part I: Check In function, the function we program in this part is really similar to the Project 1 instand of Project 1 create the repo, we added the create manifest files to this function and deleted the ArtID calculation part.
Part II: Check Out function, the algorithm we used during this function is vector and string. We using it to find the addresses of the file. And after we check out the files, it also create a manifest file for the check out files.
Part III: Label function, we used the maps algorithm. Because each manifest name can have multiple labels but each label only can aim to one manifest name. So the maps algorithm is working with it each key have multiple values but each value only have one key.

Contents:
There are two files include in the zip file, one the the Readme file another is the code cpp file.
README
362_Project.cpp

Features:
All the features from the instruction we included in the program:
Label
Check_In
Check_out


BUGS & PROBLEMS:
1.Our code can compile and work on the Visual Studio but when we test it in Linux Environment or the terminal of the Mac, it showed us some errors.
2.Check_out function should run under "debug x64" mode in visual studio, or there'll be an error. Create, Check_in and Label should run under "debug x86" mode.