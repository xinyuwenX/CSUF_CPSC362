CPSC362--03
PROJECT 3 VCSPROJCET----Merged

Team Name: OVO

Team Member: 
Xinyu Wen,  XINYUWEN@CSU.FULLERTON.EDU
Xianghui Huang,  JERRYHUANG6666@GMAIL.COM 
Yintao Wang,  WYT@CSU.FULLERTON.EDU

Intro:
This is the third part of our VCS (Version Control System) project. In this project part, we add the ability 
to merge two project trees (that are based on the same repo).

Contents:
There are two files include in the zip file, one the the Readme file another is the code cpp file.
README.txt
362-p3_OVO.cpp

Features:
All the features from the instruction we included in the program:
Create
Label
Check_In
Check_out
Merge

BUGS & PROBLEMS:
1.Our code can compile and work on the Visual Studio but when we test it in Linux Environment or the terminal 
of the Mac, it showed us bunch of errors.
2.The really big issue is that when we doing our project, we doing all the coding in the same cpp file and this 
make us feel really hard when we keep doing our next project, it is really hard for debugging, we using at least
 90% of the time in debugging.
3.The Merge function still not working really well, when we doing our Merge function, we split the code into
many sub-function, find_grandma, get_grandma, trace(trace the path), get_manifest_different_brunch, get_manifestname,
get_manifest_name_same_brunch. the big confusing problem is that we can test it sepreatly in own function, but when we  combine all the function into Merge function, it crash.
